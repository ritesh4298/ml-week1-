# Week 1: ML Basics Practice Questions

My solutions to the Week 1 practice set: loading data with pandas, splitting it,
training a Linear Regression model, and predicting house prices.

**Topics covered:** Supervised vs Unsupervised Learning, Linear Regression, Data Preprocessing

## What's in this repo

| File | What it is |
|------|-----------|
| `practice_solutions.py` | All four solutions in one script, with comments explaining each step |
| `house_prices.csv` | A small practice dataset: 100 houses with area (sq ft) and price (lakh) |

The dataset is synthetic (I generated it myself), so the numbers are for practice
and don't reflect real market prices.

## The four questions

### 1. Load a CSV using pandas and print the first 10 rows
`pd.read_csv()` reads the file into a table (DataFrame) and `.head(10)` shows the top rows.
I also check the shape and count missing values, because it's a good habit to look
at the data before using it.

```
   area_sqft  price_lakh
0       3334       176.0
1       2375       121.7
2       2552       112.0
...
The file has 100 rows and 2 columns.
Missing values: 0
```

### 2. Split the dataset into train/test using sklearn
`train_test_split` keeps 80% of the rows for learning and hides 20% for testing.
Testing on data the model has never seen is the only fair way to check it.
`random_state=42` makes the shuffle repeatable.

```
Training rows: 80
Testing rows:  20
```

### 3. Train a Linear Regression model and check accuracy
The model fits a straight line between area and price.
Because price is a number rather than a category, "accuracy" here means the
**R² score** (1.0 is perfect, 0 is no better than guessing the average),
along with the average error.

```
Learned slope (price per sqft): 0.0472 lakh
Learned intercept:              2.49 lakh
R2 score on test data:          0.952
Mean absolute error:            6.87 lakh
```

### 4. Predict house price based on area input
Give the trained model a new area and it returns a price.
For example, 1800 sq ft gives about 87.4 lakh.

## How to run it

```bash
pip install pandas numpy scikit-learn
python practice_solutions.py          # asks you to type an area
python practice_solutions.py 1800     # or pass the area directly
```

## What I learned

- House price prediction is **supervised learning**: the training data comes with the
  right answers (prices), and the model learns the link between area and price.
- A high R² on 20 test rows is encouraging, but it's a small test set and the data is
  synthetic, so I wouldn't trust it as proof of real-world accuracy.
- A straight line gets unreliable outside the area range it was trained on, so the
  script warns when the input is outside that range.
