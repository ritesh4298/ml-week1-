"""
Week 1 - ML Basics: Practice Questions
--------------------------------------
Topics: Supervised vs Unsupervised Learning, Linear Regression, Data Preprocessing

Run it:
    python practice_solutions.py            (it will ask you for an area)
    python practice_solutions.py 1800       (or pass the area directly)

Note: house prices are a *supervised* learning problem. We have the
answers (prices) for our training data, and we want the model to learn
the link between area and price. No answers given = unsupervised.
"""

import sys

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split


# ---------------------------------------------------------------
# Q1. Load a CSV using pandas and print the first 10 rows
# ---------------------------------------------------------------
print("=" * 55)
print("Q1. First 10 rows of the dataset")
print("=" * 55)

df = pd.read_csv("house_prices.csv")
print(df.head(10))
print(f"\nThe file has {df.shape[0]} rows and {df.shape[1]} columns.")

# Quick sanity check before modelling: any gaps in the data?
print("Missing values:", int(df.isnull().sum().sum()))


# ---------------------------------------------------------------
# Q2. Split the dataset into train/test using sklearn
# ---------------------------------------------------------------
print("\n" + "=" * 55)
print("Q2. Train/test split")
print("=" * 55)

X = df[["area_sqft"]]   # input (feature). Double brackets keep it 2-D, which sklearn wants
y = df["price_lakh"]    # output (target): what we want to predict

# 80% of the rows to learn from, 20% kept hidden to test the model fairly.
# random_state just makes the shuffle repeatable, so you get the same split each run.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("Training rows:", len(X_train))
print("Testing rows: ", len(X_test))


# ---------------------------------------------------------------
# Q3. Train a Linear Regression model and check its accuracy
# ---------------------------------------------------------------
print("\n" + "=" * 55)
print("Q3. Linear Regression: training and accuracy")
print("=" * 55)

model = LinearRegression()
model.fit(X_train, y_train)   # the model learns the best straight line here

y_pred = model.predict(X_test)

# "Accuracy" for regression isn't a percent-correct like in classification,
# because predicting an exact price is nearly impossible. We use R2 instead:
# 1.0 = perfect, 0 = no better than guessing the average price.
r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)

print(f"Learned slope (price per sqft): {model.coef_[0]:.4f} lakh")
print(f"Learned intercept:              {model.intercept_:.2f} lakh")
print(f"R2 score on test data:          {r2:.3f}")
print(f"Mean absolute error:            {mae:.2f} lakh")


# ---------------------------------------------------------------
# Q4. Predict house price based on area input
# ---------------------------------------------------------------
print("\n" + "=" * 55)
print("Q4. Predict a house price")
print("=" * 55)

if len(sys.argv) > 1:
    area = float(sys.argv[1])
else:
    area = float(input("Enter the house area in sq ft: "))

# The model was trained on a table with a column named 'area_sqft',
# so we give it the new input in the same shape.
new_house = pd.DataFrame({"area_sqft": [area]})
predicted_price = model.predict(new_house)[0]

print(f"\nA house of {area:.0f} sq ft is predicted to cost about "
      f"{predicted_price:.1f} lakh.")

# Small honesty check: our data only covers some areas, and a straight
# line gets shaky outside that range.
low, high = df["area_sqft"].min(), df["area_sqft"].max()
if not (low <= area <= high):
    print(f"(Careful: training areas ranged from {low} to {high} sq ft, "
          f"so this guess is an extrapolation.)")
